package com.rentflicks.markers;

public interface Authenticate {

}
