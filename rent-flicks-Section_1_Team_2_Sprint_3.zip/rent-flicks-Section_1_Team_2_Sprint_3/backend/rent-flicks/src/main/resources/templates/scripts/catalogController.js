/*var flicks = [
		{
			name : "The Da Vinci Code",
			year : 2012,
			image : "http://ia.media-imdb.com/images/M/MV5BMjIxMjQyMTc3Nl5BMl5BanBnXkFtZTcwMTA1MDUzMw@@._V1_SX300.jpg",
			plot : "A murder inside the Louvre and clues in ..."
		},
		{
			name : "Gravity",
			year : 2014,
			image : "http://ia.media-imdb.com/images/M/MV5BNjE5MzYwMzYxMF5BMl5BanBnXkFtZTcwOTk4MTk0OQ@@._V1_SX300.jpg",
			plot : "A medical engineer and an astronaut work..."
		},
		{
			name : "Martian",
			year : 2015,
			image : "http://ia.media-imdb.com/images/M/MV5BMTc2MTQ3MDA1Nl5BMl5BanBnXkFtZTgwODA3OTI4NjE@._V1_SX300.jpg",
			plot : "During a manned mission to Mars, Astronau..."
		} ]
angular.module('rentFlicks').controller('CatalogController', [$scope, function($scope) {
	$scope.flicks = flicks;
}]);*/