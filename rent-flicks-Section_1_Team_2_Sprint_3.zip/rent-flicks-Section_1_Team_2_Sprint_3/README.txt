This project is done towards term project for ITCS 6112 for Fall 2015.
This is a web application system to share the movies with peers of the system.

Team Members:

Aniruddha Atre
Himanshu Agarawal
Madhuvani Vanam
